<?php

$numero=$_POST["numero"];

echo "<h3>La conversión a número es: ".bindec($numero)." </h3>";


?>